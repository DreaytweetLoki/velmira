VELMIRA ART WEBSITE
Open index.html in a browser to preview.

Before publishing:
1. Replace the placeholder WhatsApp number 2340000000000 in index.html with the real business WhatsApp number.
2. Replace the three decorative product blocks with real earring photos when available.
3. Add the official Velmira logo when it is ready.
